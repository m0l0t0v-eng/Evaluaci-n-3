/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConexionDB1;
import modelo.Jugador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class JugadorDAOImpl implements JugadorDAO {

    private static final String INSERT_SQL =
            "INSERT INTO jugador (nombre, energia) VALUES (?, ?)";

    private static final String SELECT_ALL_SQL =
            "SELECT id, nombre, energia FROM jugador";

    @Override
    public void agregar(Jugador j) throws Exception {
        try (Connection con = ConexionDB1.getConexion();
             PreparedStatement ps = con.prepareStatement(INSERT_SQL)) {

            ps.setString(1, j.getNombre());
            ps.setInt(2, j.getEnergia());
            ps.executeUpdate();
        }
    }

    @Override
    public List<Jugador> listar() throws Exception {
        List<Jugador> lista = new ArrayList<>();

        try (Connection con = ConexionDB1.getConexion();
             PreparedStatement ps = con.prepareStatement(SELECT_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Jugador j = new Jugador();
                j.setId(rs.getInt("id"));
                j.setNombre(rs.getString("nombre"));
                j.setEnergia(rs.getInt("energia"));
                lista.add(j);
            }
        }

        return lista;
    }
}