/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Jugador;

public class Jugador {
    private int id;
    private String nombre;
    private int energia;

    public Jugador() {
    }

    public Jugador(String nombre, int energia) {
        this.nombre = nombre;
        this.energia = energia;
    }

    public Jugador(int id, String nombre, int energia) {
        this.id = id;
        this.nombre = nombre;
        this.energia = energia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEnergia() {
        return energia;
    }

    public void setEnergia(int energia) {
        this.energia = energia;
    }
}