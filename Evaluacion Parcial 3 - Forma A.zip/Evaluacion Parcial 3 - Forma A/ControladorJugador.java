/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.JugadorDAO;
import dao.JugadorDAOImpl;
import modelo.Jugador;
import java.util.List;

public class ControladorJugador {

    private final JugadorDAO dao;

    public ControladorJugador() {
        this.dao = new JugadorDAOImpl();
    }

    public void agregarJugador(String nombre, int energia) throws Exception {
        Jugador j = new Jugador(nombre, energia);
        dao.agregar(j);
    }

    public List<Jugador> listarJugadores() throws Exception {
        return dao.listar();
    }
}